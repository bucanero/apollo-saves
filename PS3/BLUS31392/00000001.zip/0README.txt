LEGO: THE HOBBIT - 99.4% GAME SAVE (NORTH AMERICA)


* This save is unsigned so it can be used on any PS3 account. *
* No need to resign :-)                                       *

If you are having trouble getting to 100% completion, this save will help you.
There are only two things left to complete:

1. Buy the Blacksmith in Bree.
2. "The Art of Combat" quest for Red Brick #32 ("Always Loot Silver").
   It's on top of the mountain near where you start in Erebor.

That said, you can also use this save to get *all* non-story trophies, so it's
useful if you need help getting to 100% trophy completion, too.  Below, I have
detailed what you need to do to obtain any of the non-story trophies.  Enjoy!

----------------------------------------

- THE UNASSESSABLY WEALTH

As soon as you load the save, you will pick up a few studs.

----------------------------------------

- MASTER BUILDER

 1. Press Select to bring up the map.
 2. Choose a green banner, these are the story levels.
 3. Navigate left/right to the level "Barrels Out Of Bond". (11th level)
 4. Choose "Free Play" then Choose "Escaping the Woodland Realm".
 5. Choose any character (press X twice).
 6. Go to the left and destroy the table.
 7. Hold Circle and build up the pieces.
 8. Stand to the right of the working bench and press Circle.
 9. Throw in the necessary resources, the mini-game will start.
10. If your bonus counter gets to 0, press Circle to go back and try again.
11. Complete the mini-game and get any amount of bonus studs from it.

----------------------------------------

- THAT'S WHY WE NEED A BURGLAR!
- THE GREED OF DWARVES
- DOILIES AND YOUR MOTHER'S DISHES
- OBJECTS OF GREAT BEAUTY
- UNEQUALLED SKILL OF THE DWARVES
- LABOURING IN THE VILLAGES OF MEN
- OUR LONG FORGOTTEN GOLD

1. Load any level in Free Play.
2. Press Start and select "Quit to Middle-earth".
3. Choose "Save and Exit"
4. Trophies will pop on the score screens.  Feel free to wait on the last
   "Quit to Middle-earth" score screen for the remaining trophies to pop.

----------------------------------------

- HARDLY BURGLAR MATERIAL

In the Middle-earth hub, upon loading a save or exiting a lavel, you'll be in
front of the loot dispenser in Erebor. Go to it, press Circle, then buy
anything. You can then exit out of it.

----------------------------------------

- WEALTH LIES IN THE EARTH

1. Hold Triangle and choose "Extra Characters" at the bottom.
2. Choose a character with the ability "mine LEGO loot":
   - Bofur (1st row, number 13 from the left)
   - Bofur (Lake-town) (5th row, number 12 from the left)
3. Find a mining spot (a shiny pile of ore).
4. Press Square at it with Bofur to start the mini-mining-game.
5. Press Square when the arrow is on the middle part (the part with most color
   on it).
6. Quickly press Circle before you hit it to abort.  This way you can have an
   infinite amount of tries on one ore.  If you get it right, the trophy will
   pop even if you didn't hit it.

----------------------------------------

- EVER "THE PEOPLE'S CHAMPION"

In the Middle-earth hub, upon loading a save or exiting a lavel, you'll be in
front of the old castle in Erebor (the one with the loot dispenser inside).

Behind the eagle statue, you'll see a path lined with a short wall.  If you
played through story, you'll remember this as the path you took to go to the
last two levels.

Go down the path to the spot where the path and wall heads off to the left,
the gold studs form an arrow pointing to the right, and there's a single
snowman just sitting there.

Now, you'll want to go up that mountain to get to "The Art of Combat" quest
for Red Brick #32 ("Always Loot Silver").  There are two ways to get up there
from here.  One involves going up the tower to the left, which means a lot of
jumping and switching characters.  I'll describe the simplier method.

Hold Triangle, and choose the "Mount" option on the left to load a horse.
Climb the mountain in front of you, trying to keep to the white parts. Jumping
helps too. It's a bit of a struggle, but you should be able to get up there
without too much trouble.

Once you are finally on top, jump off your horse, stand in the circle in front
of the Dwarf, and press Circle.

Also, don't forget to buy the Red Brick, as it is needed for 100% completion.
Just go up to it, press Circle, then buy it.

----------------------------------------

- LORD OF THE PRANCE

1. Select any character.
2. Hold Triangle, choose the "Treasure Trove" option.
3. Equip all three of these (the top 4 inventory rows do NOT count):
   - Dazzle Wig (3rd row, number 8 from the left)
   - Mithril Rhythm Stick (5th row, number 9 from the left)
   - Mithril Dance Boots (6th, row, number 13 from the left)

----------------------------------------

- DAWN OF THE MUSHROOM KING

1. Hold Triangle, choose "Extra Characters", select:
   - Thorin (2nd row, number 4 from the left)
2. Hold Triangle, choose "Treasure Trove". Equip:
   - Mithril Mushroom Crown (6th row, number 3 from the left)

----------------------------------------

- BEORN AGAIN

1. Hold Triangle, choose "Extra Characters", select:
   - Beorn (3rd row, first one from RIGHT)
2. Hold Circle, you are now a bear.

----------------------------------------

- STONE GIANT STOMP
- SOMEONE TO SHARE IN AN ADVENTURE

Turn on a second controller, then press start with Player 2 to join.

If you just did the quest at the top of the mountain for the "Ever The People's
Champion" trophy, STAY THERE!  The top of that mountain is where you'll want to
be for this.  If not, go to the top of the mountain described above for that
trophy; lest I repeat the same directions here.

There will be an icon on your minimap that looks like a stone giant (similar to
the icon on the "Over Hill and Under Hill" level). It is right there on the
mountain you climbed. Go there and press Circle, then choose Yes.  You'll have
to start it in co-op mode (2 Player split-screen) for the "Someone To Share In
An Adventure" trophy.

You are now a Stone-giant. Destroy stuff until you get 1,000,000 studs in the
bonus level.  Your Player 2 doesn't have to move at all.

----------------------------------------

- TEAM BUILDING
- BRO'S BEFORE GOLD

If you're continuing from above, you can now turn off your second controller.

1. Press Select to bring up the map.
2. Find the "Caradhras" Eagle statue, and choose it to fast travel to it.
3. Hold Triangle and choose "Extra Characters".
4. Choose any character with the ability "buddy up".
5. Press Triangle to switch to the other character in your party.
6. Hold Triangle, choose "Extra Characters", and select one of the following:
   - Balin (1st row, number 11 from the left)
   - Bifur (1st row, number 12 from the left)
   - Bofur (1st row, number 13 from the left)
   - Bombur (1st row, number 14 from the left)
   - Dori (1st row, number 15 from the left)
   - Dwalin (1st row, number 16 from the left)
   - Fili (1st row, number 17 from the left)
   - Kili (1st row, number 18 from the left)
   - Gloin (1st row, number 19 from the left)
   - Nori (2nd row, number 1 from the left)
   - Oin (2nd row, number 2 from the left)
   - Ori (2nd row, number 3 from the left)
   - Thorin (2nd row, number 4 from the left)
7. As any of the previously characters, stand close to your "buddy" and press
   Circle to "buddy up". You now control both characters.
8. There are usually a few orcs nearby. Kill one (Square) while you are in
   "buddy up" mode.
9. Repeat Steps 4-8 with yourself controlling each of the characters.  It
   doesn't matter who your buddy is, as long as you perform a kill while
   buddied-up and controlling each of the above. This will also bring you
   over 50 buddy-up attacks for "Bros Before Gold".

----------------------------------------

- CONJURER OF CHEAP TRICKS

If you're continuing from the above, stay in Caradhras. If not, go to Caradhras.

1. Hold Triangle, choose "Extra Characters", select:
   - Gandalf (1st row, number 10 from the left)
2. If there are no orcs nearby, enter the cave right next to the eagle statue,
   then exit again.  The Orcs should be back.
3. Go up to one and Hold Circle, fill up the bar, then release.
4. The Orc should be dazzled, which will make the 50th dazzle.

----------------------------------------

- WHO IS THIS HORRID CREATURE?

1. Press Select to bring up the map.
2. Find the "Lake-town" Eagle statue.
3. Choose it and fast travel to it.
4. Enter the door to the right of you (when you are facing the statue).
5. Stand on one of the brown pads.
6. Press X. Press Left. Press X. Choose any. Press Circle twice to exit out.

----------------------------------------

- TO BE CONTINUED...
- QUITE A MERRY GATHERING

1. Press Select to bring up the map.
2. Find the "Bree" Eagle statue.
3. Choose it and fast travel to it.
4. In Bree, there is a Blacksmith.
5. Go to it, wait for the door to open and head inside.
6. Inside, go to the left and up to the Blacksmith.
7. Press Circle then X to buy him.

----------------------------------------

If you have done all 16 of the Story trophies. and all of the ones described
above, you will also unlock the Platinum:

- THE ROAD GOES EVER ON (PLATINUM)

----------------------------------------
END
