Mission Name: The Calm
Author: tagamaynila
Type: single player
Objective: assasinate the target
Tileset: merchant mansion
Character: All (preferably Rikimaru)
Time Limit: none
Stealth Requirement: none
Save Slot: 1

Description: News of an invasion of a town in Godha's realm was causing a stir among the citizens of Godha. Find the truth behind this supposed invasion plot and do what is necessary to prevent it.