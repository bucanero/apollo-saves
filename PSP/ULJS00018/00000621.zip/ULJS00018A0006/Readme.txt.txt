Readme v1.0
-------------------
Mission:     Shadows of Vengeance Pt.1: Corruption
Author:      VMethos/Patrick
Type:        Regular (single player)
Objective:   Assassinate
Tileset:     Bamboo Forest
Character:   All (Rikimaru intended)
Time Limit:  No
Stealth Req: No

Description: 

    Local officials have been abusing their power
    to commit atrocious crimes upon the girls of
    the town.  But rumors have leaked of this
    treachery and Lord Ghoda intends to put a stop
    to such corruption.

    You must deliver justice with cold steel and
    avenge those who have been wronged.
---------------------