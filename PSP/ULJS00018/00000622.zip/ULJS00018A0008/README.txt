----------
Mission Name: - Punishment
Author: - Sean Farrell / lyam
Type: - Single Player 
Objective: - Assasinate Echigoya
Tileset: - Echigoya Estate
Character: - Any
Time Limit: - None
Stealth Requirement: - No


Installation:-
----------

Drag and drop the contents of this folder into the SaveData directory of your PSP.  CAUTION: This mission will overwrite any others with the same folder name.

Description:--
----------
This mission is a remix of Tenchu:Stealth Assassin's Punish the Evil Merchant.  I've added some extras and hopefully you'll enjoy the surprises.  Take your time an explore.  I've tried to make it visually appealing so you'd enjoy just investigating the environment, if nothing else. 
