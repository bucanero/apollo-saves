Readme v1.0
-------------------
Mission:     Pitfalls
Author:      VMethos/Patrick
Type:        Regular (single player)
Objective:   Arrive
Tileset:     Mountain Pass
Character:   All
Time Limit:  No
Stealth Req: No

Description: 

    This is just a demonstration of difficult jumps that can be
created with this editor.  The northern path can only be traversed
by the bear's ability to climb up walls with its claws.

    The main path is a series of jumps that can be performed by
double-jumping and then using the wallkick for extra distance to the
platform.  The female characters are a little better at this method
due to the extra run up the wall that they get.

    To create these jumps, place a tile at the same elevation or one step
higher (very difficult) 3 spaces out and one space to the side of the initial
jumping point.  Use a wall that is not grapple-able between the jumping
platform and the landing platform.
---------------------