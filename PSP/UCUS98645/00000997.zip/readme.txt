make sure you back up ur savedata file before putting this in there if you want to continue YOUR campagn.


also just replace the accountNAMEhere with your REAL account's name to keep your online rank and stats