[About Saves]
Just a few things to note about these saves,
They will take the first 3 slots. 
Slot 1 is normal storyline with All items,dolls, and music, Laharl is fightable
Slot 2 is Asagi storyline with with All items,dolls, and music, Laharl is fightable [Currently on Asagi's last chapter]
Slot 3 is Asagi storyline with with All items,dolls, and music, Laharl is beaten and replaced with Baal [Currently on Asagi's last chapter]

[Misc.]
Personally I would like to thank a few people

First off I would like to thank NIS America and NIS for making a fun platformer to the PSP.

I would also like to thank RyuKage2007's - Collectable Item Guide that can be
found on various websites, without it I would have never gotten all the music files.

And finally I would like to thank Novo for reminding me about adding the Prinny Raid Skill. 

This save should be only found at GameFaqs, and http://m-world.web44.net/

Also you can view some of my Prinny videos at my youtube channel - http://www.youtube.com/user/MXEXE
Other than that enjoy it ^_^