Put the folder NPUG80221DATA in PSP/SAVEDATA folder of your psp.Make sure you only have 1 psp savedata of this
game.ENJoy!:)