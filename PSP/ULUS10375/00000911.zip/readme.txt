
   -  Star Ocean: Second Evolution Difficulties              -Help support the
   -  By:  Tzepish                                            anti-ASCII art
           tzepish at gmail dot com                           movement!

*******************************************************************************


  A.)  Basic Info


  * This archive should contain the following:

  - readme.txt:           The file you are currently viewing.

  - ULUS10375SO20024:     1st save folder (Rena   / Earth)
  - ULUS10375SO20025:     2nd save folder (Rena   / Galaxy)
  - ULUS10375SO20026:     3rd save folder (Rena   / Universe)
  - ULUS10375SO20027:     4th save folder (Claude / Earth)
  - ULUS10375SO20028:     5th save folder (Claude / Galaxy)
  - ULUS10375SO20029:     6th save folder (Claude / Universe)

    Copy these folders to your PSP\SAVEDATA directory on your memory stick.

*******************************************************************************


  B.)  What Do These Save Files Do?


    These save files do two things:

      * Unlock Galaxy and Universe difficulties.
      * Start a New Game with no Talents except Nimble Fingers (and Blessing of
          Mana).

    Instead of starting a New Game, simply load from the file that corresponds
    to the character and difficulty you wish to play.

    I recommend keeping these six saves in the bottom slots (in case you want
    to start new games from them in the future), and saving the games that you
    start from them in different slots.

*******************************************************************************


  C.)  Q/A


    1.) Why did I make these files?

        These files are mostly time savers.  Since your starting Talents are
        normally determined randomly, players would constantly start New Games
        in order to try to start with Nimble Fingers and/or as few Talents as
        possible.  Now you may simply load from one of these saves to get the
        best starting Talents possible.

        Also, many players have already played the PS1 version of this game to
        death, and so they want to jump straight into Universe mode without
        having to spend the time and effort unlocking it.  As long as you keep
        one of these save files on your memory stick (even the Earth mode
        ones), you will have Galaxy and Universe mode unlocked.


    2.) How did I make these files?

        * Started a New Game.
        * Activated the CWCheat code that blanks Claude's / Rena's Talents
            (except Nimble Fingers and Blessing of Mana).
        * Activated the CWCheat code for the Debug Menu.
        * Used the Debug Menu to set the monster kills = 2000 (to unlock the
            difficulties).  (Monster Kills is the 8th option down under the
            COMPLETERATE menu.)
        * Turned on Message Skipping in the Settings Menu (it's so annoying
            with this turned off).
        * Proceeded to the first Save Point and saved the game.
        * Repeated for both characters on each difficulty (6 slots).
        * Used Adobe Photoshop to modify the save icons.


    3.) Is using these files considered "cheating"?

        Arguably, starting with the blank Talents is something that was
        possible anyway - using these files simply saves you the time of
        constantly rerolling them.  If you want, though, you could waste Skill
        Points by using them on skills before training the Determination
        skill.

        I would say that you shouldn't be considered a cheater if you use my
        saves.  Just play the game!

*******************************************************************************


  D.)  The Disclaimer!


    --  (C) 2009  Tzepish (Blaine Higdon)

    --  This archive is not to be distributed with any other files.
        
    --  Tzepish is not responsible for any damages done to your computer,
        whether you use his files or not.
