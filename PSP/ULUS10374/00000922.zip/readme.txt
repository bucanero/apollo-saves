
   -  Star Ocean: First Departure Difficulties
   -  By:  Tzepish
           tzepish at gmail dot com

*******************************************************************************


  A.)  Basic Info


  * The archive you have downloaded should contain the following:

  - readme.txt:           The file you are currently viewing.

  - ULUS10374SO10027:     1st save folder (Difficulty = Earth    / Normal)
  - ULUS10374SO10028:     2nd save folder (Difficulty = Galaxy   / Hard)
  - ULUS10374SO10029:     3rd save folder (Difficulty = Universe / Very Hard)

    Copy these folders to your PSP\SAVEDATA directory on your memory stick.

*******************************************************************************


  B.)  What Do These Save Files Do?


    These save files allow you to access the Galaxy and Universe difficulty
    modes.  The higher difficulties were dummied out of the game, and there's
    no normal way to select them without using custom PSP firmware and cheat
    programs - that's why I made these files, so you can start a new game on a
    higher difficulty, if you wish - even without cheats or custom firmware.

    Instead of starting a New Game, simply load from the file that corresponds
    to the difficulty you wish to play:

      * Slot 28 = Earth mode    (Difficulty = Normal    = Default)
      * Slot 29 = Galaxy mode   (Difficulty = Hard      = 150% Enemy Stats)
      * Slot 30 = Universe mode (Difficulty = Very Hard = 200% Enemy Stats)


    Since Roddick's starting Talents are normally determined randomly, they
    have been blanked in these saves (he has no Talents).  The Earth mode save
    exists just in case you want to start an Earth mode game with zero Talents
    on Roddick.

    I recommend keeping these three saves in the bottom slots (in case you want
    to start new games from them in the future), and saving the games that you
    start from them in different slots.

*******************************************************************************


  C.)  Q/A


    1.) Why did I make these files?

        I'm on a constant quest to make the games I love more fun and
        convenient to play, as well as extending their lifespans.  I wanted
        more people to have access to the higher difficulties than just the
        people with custom firmware that know how to use CWCheat.  It's hard
        for me to imagine why the developers thought removing Galaxy and
        Universe mode was a good idea - I wanted to undo their mistake.  So
        here you go: with these saves, you may now play through this game on
        higher difficulties, just like Star Oceans 2 and 3.


    2.) How did I make these files?

        * Started a New Game.
        * Activated the CWCheat code that blanks Roddick's Talents.
        * Activated the Save Anywhere code to save the game to slot 28.
        * Activated the Galaxy difficulty code and saved to slot 29.
        * Activated the Universe difficulty code and saved to slot 30.
        * Used MS Paint to modify the save icons.


    3.) Is using these files considered "cheating"?

        Arguably, starting with the blank Talents is something that was
        possible anyway - using these files simply saves you the time of
        constantly rerolling them.  If you want, though, you could waste Skill
        Points by using them on skills before training the Determination
        skill.

        I would say that you shouldn't be considered a cheater if you use my
        saves.  Just play the game!

*******************************************************************************


  D.)  The Disclaimer!


    --  (C) 2008  Tzepish (Blaine Higdon)

    --  This archive is not to be distributed with any other files.
        
    --  Tzepish is not responsible for any damages done to your computer,
        whether you use his files or not.
