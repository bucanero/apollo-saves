This is a clean save, meaning you can start a new Story Mode.

This also means you have to complete one level (or perhaps just
save once) for a few things to be unlocked.