-paste this data in
-pega estos datos en

   MS0:\PSP\SAVEDATA

-this data is in the 1rst slot of game save data,
so i suggest u to save your data in the 2nd slot BEFOREput this data

-este save ocupa el primer slot de game saved data, asi que si tienes tus datos en el primero
sugiero que antes de meter estos datos, resalves tus propios datos en el 2do slot

-have a nice day =)
-ten un buen dia =)