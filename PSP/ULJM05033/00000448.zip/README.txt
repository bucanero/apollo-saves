=========================================
Winning Eleven 9 Ubiquitous Edition (JAP)
=========================================

This option file for the Japanese version of Winning Eleven 9 
is based on one available on the net. I have updated the file 
with transfers from the January 2006 transfer window using 
ed13689's "Name Edit/Transfers Guide" available on GameFAQs.

The file should live in the location PSP\SAVEDATA.

Points to note:

-Available clubs are from the 04/05 season,
-Summer 2005 transfers may not be complete,
-International squads are not be up to date,
-Club starting lineup may not be correct (except English League),
-Some club and player names are locked from change by the game.

Comments and suggestions are welcome. If you can help correct non 
English League lineups then that would be fantastic!

The file should live in the location PSP\SAVEDATA.

Email: varsas@hotmail.com