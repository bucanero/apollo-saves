RedddMonkey's Yugioh Tag Force 2 Game Save
CREATED BY: RedddMonkey (Derek)
UPLOADED: 12/27/2007

----------------
INSTRUCTIONS:
----------------
To install this gamesave on your PSP, copy the folder ULUS103020001 and all its contents to your PSP or Memory Stick at X:\PSP\SAVEDATA.

----------------
FEATURES:
----------------
- 99x ALL Cards (including Egyptian God Cards)
- No Banlist
- 900 Billion DP
- Duelist Level 99
- Any character can be your partner: All characters (001 - 115) have been unlocked as partners including Sadie, Dorothy, Viper, Zane, Mimicr
- Unlocked Mimicry (#035) - You can edit his deck entirely, in Free Duel you pick your own decklist for him to use
- Almost all opponent deck recipes are unlocked for Free Duel mode.
- Game is beaten with 15 partners (8 + 4 + 3)
- 23 Great and Fun Decklists to try!  (See Below)

------------------------------------------------
GAME BEATEN WITH THE FOLLOWING CHARACTERS:
------------------------------------------------
 PAGE 1        PAGE 2         PAGE 3
-------------- -------------- ----------------
 - Jaden       - Sartorius    - Mimicry
 - Syrus       - Zane         - Masha
 - Alexis      - Axel         - Inoso
 - Chazz       - Sadie
 - Tyranno
 - Aster
 - Blair
 - Jesse

--------------------
DECKLIST OVERVIEW:
--------------------
 1 Perfect Circle - Netdecked from Metagame; Shonen Jump Tournament winning "Perfect Circle/Spin" deck
 2 Burning Desire - Burn Deck
 3 Resurrection - Zombie Revival Deck
 4 Diamond Turbo - Deck centered around Destiny Hero Diamond Dude and his effect
 5 Meet Ur Demise - Demise One Turn Kill (OTK) Deck
 6 >~DiMeNtiA~< - Necroface / Soul Absorbsion / Remove from Play Deck
 7 =[DiMenNtEd]= - Another Remove from Play deck focusing on the D.D. Warriors Toolbox
 8 Really Sphinx - Fun and Semi-Competitive Andro/Teleia/Theinen Sphinx Deck
 9 Black and White - Light and Dark Discard Deck with Goldd/Sillva
10 Drawing is Fun! - Oppenent Deckout Deck
11 Damage Detour - Defensive Deck focusing on high defense and deflecting damage back at your opponent.  (Amazoness Swordswoman + Mistobody)
12 Pacman - Flip-facedown Deck (Swarm of Scarabs/Locusts, etc)
13 Gadget Factory - Red/Green/Yellow Gadget Control Deck
14 Catch 22 - Fire/Burn Deck centered around Inferno Reckless Summon and "Catch 22" situations such as 2x Solar Flare Dragons, 2x Marauding Captain, Command Knight + Marshmellon/Spirit Reaper, etc).
15 iToons - Fun and Semi-Competitive Toon Deck
16 Water You Doing - Legendary Ocean Water Deck
17 Dark Justice - Leisure Deck centered around Sorcerer of Dark Magic
18 I Lava You! - Lava Golem Fiend Deck
19 VolcanicMonarch - Volcanic Monster / Monarch Deck
20 Raiza's Dragon - Perfect Circle Deck / Light and Darkness Deck
21 Back at Ya! - Damage Reflection Deck
22 That was Easy! - STAPLES (get it?): All cards are from the Restricted or Semi-Restricted List
23 Entrapment - All Trap Deck (not very competitive)



