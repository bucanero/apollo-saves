----Contact Information----
http://www.consoleDiscussions.com


----Installation----
Kind of obvious install it into the SAVEDATA folder.


----Notice----
Those of you who download my gamesave may
NOT modify it in anyway or upload it anywhere
as your own.

Gamesave is �Johnny McKinney


----Note----
Some may have an issue with 3 medals not being unlocked. To solve this issue, go into single player and it will display that you have unlocked the Sightseer medal. Once you see this, just press start and exit single player. Now all the medals will be unlocked.