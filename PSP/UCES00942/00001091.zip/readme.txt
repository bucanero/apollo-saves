100% Secret Agent Clank save.
PSP, region Europe.

1st save - made after 1st playthrough
2nd save - Everything, I mean everything is unlocked and maxed out.

shinian