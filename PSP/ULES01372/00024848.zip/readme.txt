Thanks to azertyxp for the original save file.
Merci 	� azertyxp pour la sauvegarde originale.