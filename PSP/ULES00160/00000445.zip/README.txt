Just add the folder (ULES001600013000) into the 'save data' folder in your PSP directory.

Happy gaming :D