This save file has DLCs tied to it. In order for it to load, the game needs to recognise these save files.
All DLCs are free on the PSN store and can be downloaded, save for the one in reAddCont which is a modified DLC.

Copy all the folders in this .zip file to ux0: and you should have no problems. Have fun!